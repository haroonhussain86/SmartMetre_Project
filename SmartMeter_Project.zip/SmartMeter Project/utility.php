<?php
require_once ('Models/Utility.php');

$utilityManager = new Utility();
$view = new stdClass();
$requestedUtility = 'gas';
$tariff = $utilityManager::PRICE_GAS;
$view->pageTitle = ucfirst(strtolower($requestedUtility));
$view->chartColor = '#0275D8';

//route to electricity details
if ($_GET['show'] == 'elec') {
    $requestedUtility = $_GET['show'];
    $view->pageTitle = 'Electricity';
    $view->chartColor = '#fdba04';
    $tariff = $utilityManager::PRICE_ELECTRICITY;
}


//Get today and yesterday
$view->yesterday = $utilityManager->fetchData(strtoupper($requestedUtility),'PT1M','yesterday midnight','today midnight');
$view->today = $utilityManager->fetchData(strtoupper($requestedUtility),'PT1M','today midnight','tomorrow midnight');


//Get all months
$view->January = $utilityManager->fetchData(strtoupper($requestedUtility) ,'PT1M','first day of January this year','first day of February this year');
$view->February = $utilityManager->fetchData(strtoupper($requestedUtility),'PT1M','first day of February this year','first day of March this year');
$view->March = $utilityManager->fetchData(strtoupper($requestedUtility),'PT1M','first day of March this year','first day of April this year');
$view->April = $utilityManager->fetchData(strtoupper($requestedUtility),'PT1M','first day of April this year','first day of May this year');
$view->May = $utilityManager->fetchData(strtoupper($requestedUtility),'PT1M','first day of May this year','first day of June this year');
$view->June = $utilityManager->fetchData(strtoupper($requestedUtility),'PT1M','first day of June this year','first day of July this year');
$view->July = $utilityManager->fetchData(strtoupper($requestedUtility),'PT1M','first day of July this year','first day of August this year');
$view->August = $utilityManager->fetchData(strtoupper($requestedUtility),'PT1M','first day of August this year','first day of September this year');
$view->September = $utilityManager->fetchData(strtoupper($requestedUtility),'PT1M','first day of September this year','first day of October this year');
$view->October = $utilityManager->fetchData(strtoupper($requestedUtility),'PT1M','first day of October this year','first day of November this year');
$view->November = $utilityManager->fetchData(strtoupper($requestedUtility),'PT1M','first day of November this year','first day of December this year');
$view->December = $utilityManager->fetchData(strtoupper($requestedUtility),'PT1M','first day of December this year','first day of January next year');

$view->usage['yesterday'] = (int)$utilityManager->calculateTotalUsage($view->yesterday);
$view->usage['today'] = (int)$utilityManager->calculateTotalUsage($view->today);
$view->usage['January'] = (int)$utilityManager->calculateTotalUsage($view->January);
$view->usage['February'] = (int)$utilityManager->calculateTotalUsage($view->February);
$view->usage['March'] = (int)$utilityManager->calculateTotalUsage($view->March);
$view->usage['April'] = (int)$utilityManager->calculateTotalUsage($view->April);
$view->usage['May'] = (int)$utilityManager->calculateTotalUsage($view->May);
$view->usage['June'] = (int)$utilityManager->calculateTotalUsage($view->June);
$view->usage['July'] = (int)$utilityManager->calculateTotalUsage($view->July);
$view->usage['August'] = (int)$utilityManager->calculateTotalUsage($view->August);
$view->usage['September'] = (int)$utilityManager->calculateTotalUsage($view->September);
$view->usage['October'] = (int)$utilityManager->calculateTotalUsage($view->October);
$view->usage['November'] = (int)$utilityManager->calculateTotalUsage($view->November);
$view->usage['December'] = (int)$utilityManager->calculateTotalUsage($view->December);


//calculate cost yesterday vs today
$view->cost['yesterday'] = $utilityManager->calculatePrices($utilityManager->calculateTotalUsage($view->yesterday), $tariff);
$view->cost['today'] = $utilityManager->calculatePrices($utilityManager->calculateTotalUsage($view->today), $tariff);



$view->now = $utilityManager->getDateFormat('now')->format('d M Y H:m');

require_once ('Views/layout/header.phtml');
require_once ('Views/utility.phtml');
require_once ('Views/layout/footer.phtml');