<?php
require_once ('Models/Utility.php');

$utilityManager = new Utility();
$view = new stdClass();
$view->Gas = $utilityManager->fetchData('GAS','PT1M','2019-01-14','2019-01-15');
$view->Elec = $utilityManager->fetchData('ELEC','PT1M','2019-01-14','2019-01-15');

var_dump($view->Gas);
var_dump($view->Elec);