<?php

class Api
{
    protected $curl, $baseURL;

    public function __construct()
    {
        $this->baseURL = 'https://adhocapi.energyhive.com/hive/ac89ccdce8e878e227a93f050413c7d8/type/';
        $this->ApiKEY = '78c4da90ba4a93adc4f50e89427caef9';
    }

    public function get(array $data)
    {
        $requestParams =  $data['type'] . '/?units='. $data['units'].'&from='. $data['from'].'T'. $data['fromTime'].'&to='. $data['to'].'T'. $data['toTime'].'&offset=-0&period='. $data['period'].'&function=sum';
        $headers = [
            "x-auth-token: $this->ApiKEY",
            'Content-Type: application/x-www-form-urlencoded; charset=utf-8',
        ];
        $curl = curl_init();
        // Set curl options
        curl_setopt($curl, CURLOPT_URL,$this->baseURL.$requestParams);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);

        //Request data from url
        $request = curl_exec ($curl);
        $response = json_decode($request, TRUE);
        // Close request
        curl_close($curl);

        return $response['data'];
    }

}