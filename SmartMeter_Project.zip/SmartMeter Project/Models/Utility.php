<?php
require_once ('Api.php');
class Utility
{
    //prices based on ScottishPower Online fix and Save August 2018
    const PRICE_GAS = 0.02859;
    const PRICE_ELECTRICITY = 0.12376;

    protected $api;

    public function __construct()
    {
        $this->api = new Api();
    }

    public function fetchData($type,$period,$from, $to)
    {
        $from = $this->getDateFormat($from);
        $to = $this->getDateFormat($to);
        $params = [
            'units' => 'kWh',
            'from' => $from->format('Y-m-d'),
            'fromTime' => $from->format('H:i:s'),
            'to' => $to->format('Y-m-d'),
            'toTime' => $to->format('H:i:s'),
            'period' => $period,
            'type' => $type,

        ];

        $data = $this->api->get($params);
        return $data['data'];
    }


    public function getDateFormat($date)
    {
        try {
            return new DateTime($date, new DateTimeZone('GMT'));
        } catch (Exception $ex) {
            return null;
        }
    }

    public function calculateTotalUsage($consumption)
    {
        $sum = 0.00;
        $counter = 0;
        foreach ( $consumption as $data) {

            $sum = $sum + (float)$data[1];
            if($data[1] > 0.01 ){
                $counter++;
            }

        }

        return number_format(floatval($sum), 2, '.', '');
    }

    public function calculatePrices($usage, $tariff = self::PRICE_ELECTRICITY)
    {
        return number_format((float)$usage * (float)$tariff, 2, '.', '');
    }

}