<?php
require_once ('Models/Utility.php');

$utilityManager = new Utility();
$view = new stdClass();
$view->pageTitle = 'Homepage';

//Get this week data
$view->weekUsage->gas = $utilityManager->fetchData('GAS','PT1M','last sunday','now');
$view->weekUsage->elec = $utilityManager->fetchData('ELEC','PT1M','last sunday','now');

//Get last week data
$view->lastweekUsage->gas = $utilityManager->fetchData('GAS','PT1M','last sunday - 7 days','last sunday');
$view->lastweekUsage->elec = $utilityManager->fetchData('ELEC','PT1M','last sunday - 7 days','last sunday');


//define budget
$view->weeklyBudget = 50.00;

$view->thisWeek->gas = [
    'usage' => $utilityManager->calculateTotalUsage($view->weekUsage->gas),
    'cost'  => $utilityManager->calculatePrices($utilityManager->calculateTotalUsage($view->weekUsage->gas), $utilityManager::PRICE_GAS)
];

$view->thisWeek->elec = [
    'usage' => $utilityManager->calculateTotalUsage($view->weekUsage->elec),
    'cost'  => $utilityManager->calculatePrices($utilityManager->calculateTotalUsage($view->weekUsage->elec), $utilityManager::PRICE_ELECTRICITY)
];

$view->thisWeek->total = floatval($view->thisWeek->elec['cost']) + floatval($view->thisWeek->gas['cost']);

$view->lastWeek->gas = [
    'usage' => $utilityManager->calculateTotalUsage($view->lastweekUsage->gas),
    'cost'  => $utilityManager->calculatePrices($utilityManager->calculateTotalUsage($view->lastweekUsage->gas), $utilityManager::PRICE_GAS)
];

$view->lastWeek->elec = [
    'usage' => $utilityManager->calculateTotalUsage($view->lastweekUsage->elec),
    'cost'  => $utilityManager->calculatePrices($utilityManager->calculateTotalUsage($view->lastweekUsage->elec), $utilityManager::PRICE_ELECTRICITY)
];

$view->lastWeek->total = floatval($view->lastWeek->elec['cost']) + floatval($view->lastWeek->gas['cost']);

$view->prediction->nextWeek->gas = [
    'usage' => array_sum([$view->lastWeek->gas['usage'], $view->thisWeek->gas['usage']]) / 2,
    'cost' => array_sum([floatval($view->lastWeek->gas['cost']), floatval($view->thisWeek->gas['cost'])]) / 2,
];

$view->prediction->nextWeek->elec = [
    'usage' => ($view->lastWeek->elec['usage'] + $view->thisWeek->elec['usage']) / 2,
    'cost' => floatval($view->lastWeek->elec['cost']) + floatval($view->thisWeek->elec['cost']) / 2,
];

require_once ('Views/layout/header.phtml');
require_once ('Views/dashboard.phtml');
require_once ('Views/layout/footer.phtml');